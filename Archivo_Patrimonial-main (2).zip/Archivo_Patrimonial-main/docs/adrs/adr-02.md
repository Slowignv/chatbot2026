# ADR 02: Estructura y Estilo del Código

## Estado
Aceptado

## Contexto
Para evitar la degradación arquitectónica del sistema y asegurar que los cambios drásticos en los servicios perimetrales de inteligencia artificial (como modificaciones en el SDK de Google Generative AI o caídas en la plataforma externa AtoM) no obliguen a reescribir la lógica de consultas históricas, se necesita una estructura con bajo acoplamiento y alta cohesión.

## Decisión
Se adopta el patrón estructural de **Arquitectura Hexagonal (Puertos y Adaptadores)** combinado con tácticas de Diseño Guiado por el Dominio (DDD). El código se divide rígidamente en las capas autónomas de `Dominio`, `Aplicacion` e `Infraestructura`.

## Justificación Teórica (Principios de Diseño)

1. **Principio de Inversión de Dependencias (DIP):** El núcleo del negocio (Dominio) es completamente puro y agnóstico a la tecnología de persistencia o AI. Define interfaces abstractas (Puertos como `ModeloLenguajePort` o `VectorStorePort`). Los detalles técnicos de infraestructura (`GeminiAdapter` y `ChromaDBAdapter`) implementan estas interfaces externamente, de modo que las capas interiores jamás dependen de las exteriores.
2. **Principio de Responsabilidad Única (SRP):** Cada módulo o adaptador posee una única razón de cambio. Si Google actualiza su framework generativo, el impacto se mitiga y congela exclusivamente dentro de `gemini_adaptador.py`, dejando el caso de uso del chat completamente intacto.
3. **DDD (Entidades y Objetos de Valor):** Modelos de negocio puros como `PromptContextualizado` o `DocumentoPatrimonial` encapsulan las invariantes de negocio históricas. Esto eleva drásticamente la *Testeabilidad*, permitiendo ejecutar suites de pruebas unitarias masivas en milisegundos mediante la inyección de dobles de prueba (*Mocks* en memoria), sin requerir una conexión real a bases de datos vectoriales o APIs externas de red.

## Consecuencias
* **Positivas:** Independencia absoluta de proveedores externos de IA, máxima facilidad para implementar pruebas funcionales aisladas, y confinamiento seguro de errores de red en la infraestructura.
* **Negativas:** Introduce una curva de complejidad inicial alta debido al aumento en el número de carpetas estructuradas y requiere escribir código de mapeo adicional para transformar objetos crudos de infraestructura a tipos del dominio al cruzar las fronteras arquitectónicas.
