# ADR 01: Selección del Motor de Datos

## Estado
Aceptado

## Contexto
El Chatbot del Archivo Patrimonial requiere procesar y responder consultas históricas complejas formuladas en lenguaje natural. Las bases de datos relacionales convencionales (SQL) limitan las consultas a coincidencias exactas de texto estructurado, lo cual es insuficiente para resolver la cercanía conceptual y el análisis de significado requerido por los investigadores. Es mandatorio almacenar y consultar representaciones vectoriales (*embeddings*) eficientemente.

## Decisión
Se selecciona **ChromaDB** como el motor de base de datos vectorial del proyecto. Operará como un servicio independiente expuesto en el puerto 8000, interactuando de forma exclusiva a través del adaptador de salida del componente `search-service`.

## Consecuencias
* **Positivas:** Permite búsquedas semánticas directas de documentos históricos mediante métricas de distancia del coseno integradas. Su integración en Python mediante HTTP client es directa, ligera y de bajo impacto en memoria de desarrollo.
* ** Negativas:** Añade un nuevo componente de infraestructura en el stack distribuido que debe monitorearse por separado y carece de la robustez de transacciones complejas ACID tradicionales para datos relacionales.
