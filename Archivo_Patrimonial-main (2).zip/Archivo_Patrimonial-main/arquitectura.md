# Diagramas de Arquitectura (Modelo C4)

## Nivel 1: Diagrama de Contexto
Muestra cómo el sistema del Chatbot interactúa con los distintos actores de la universidad y las plataformas perimetrales de datos y lógica generativa.

```mermaid
graph TB
    subgraph Usuarios
        U1[Usuario / Investigador UAH]
        U2[Administrador del Archivo]
    end

    subgraph Sistema_Principal [Frontera del Sistema]
        SYS[Chatbot Archivo Patrimonial UAH]
    end

    subgraph Sistemas_Externos
        ATOM[Plataforma AtoM - Descripción Archivística]
        GEMINI[Google Gemini API Studio]
    end

    U1 -->|Consulta sobre patrimonio e historia| SYS
    U2 -->|Gestiona la ingesta y cargas masivas| SYS
    SYS -->|Sincroniza metadatos y objetos digitales| ATOM
    SYS -->|Envía prompts contextualizados para generación| GEMINI
    SYS -->|Retorna respuestas históricas validadas| U1
```

## Nivel 2: Diagrama de Contenedores
Este diagrama hace un zoom en el sistema para detallar los componentes ejecutables separados, sus puertos reales y sus protocolos de comunicación.

```mermaid
graph BR
    U[Usuario / Investigador] -->|HTTP / JSON| FE[Frontend Contenedor Next.js]
    
    subgraph Backend_Microservicios [Malla de Contenedores Backend]
        FE -->|HTTP / REST puerto 3000| GW[API Gateway Contenedor FastAPI]
        
        GW -->|HTTP / JSON puerto 3001| CS[Chat Service Contenedor FastAPI]
        GW -->|HTTP / JSON puerto 3002| SS[Search Service Contenedor FastAPI]
        GW -->|HTTP / JSON puerto 3003| AIS[AtoM Integration Service Contenedor FastAPI]
        
        CS -->|Llamadas a Puertos Internos| SS
    end

    subgraph Infraestructura_Persistencia_y_AI
        SS -->|gRPC / HTTP puerto 8000| CHROMA[(ChromaDB Vector Store)]
        CS -->|HTTPS / API Key| GEMINI_LLM[Google Gemini-2.5-flash]
        AIS -->|HTTP / REST puerto 8081| ATOM_EXT[Sistema AtoM Externo]
    end
```
